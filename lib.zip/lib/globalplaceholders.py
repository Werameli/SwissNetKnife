with open(".version", "r") as file:
    version = file.read()
    file.close()